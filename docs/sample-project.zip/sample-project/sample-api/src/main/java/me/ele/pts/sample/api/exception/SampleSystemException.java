package me.ele.pts.sample.api.exception;

import me.ele.contract.exception.SystemException;

/**
 * 系统级别异常,直接抛出,无法处理
 */
public class SampleSystemException extends SystemException {

    public SampleSystemException(String message) {
        super(message);
    }

    public SampleSystemException(String code, String message) {
        super(code, message);
    }

    public SampleSystemException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public SampleSystemException(String code, Throwable cause) {
        super(code, cause);
    }

    public SampleSystemException(ExceptionCode exceptionCode) {
        super(exceptionCode.getCode(), exceptionCode.getMessage());
    }

    public SampleSystemException(ExceptionCode exceptionCode, Throwable cause) {
        super(exceptionCode.getCode(), exceptionCode.getMessage(), cause);
    }

    public SampleSystemException(ExceptionCode exceptionCode, String message) {
        super(exceptionCode.getCode(), message);
    }

    public SampleSystemException(ExceptionCode exceptionCode, String message, Throwable cause) {
        super(exceptionCode.getCode(), message, cause);
    }

    @Override
    public void setCode(String code) {
        super.setCode(code);
    }

    @Override
    public String getCode() {
        return super.getCode();
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    @Override
    public String getLocalizedMessage() {
        return super.getLocalizedMessage();
    }

    @Override
    public synchronized Throwable getCause() {
        return super.getCause();
    }
}

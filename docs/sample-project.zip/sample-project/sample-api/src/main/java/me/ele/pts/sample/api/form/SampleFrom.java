package me.ele.pts.sample.api.form;

/**
 * 表单样例
 */
public class SampleFrom {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

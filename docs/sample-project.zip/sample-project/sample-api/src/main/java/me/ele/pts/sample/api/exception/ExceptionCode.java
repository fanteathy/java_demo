package me.ele.pts.sample.api.exception;

/**
 * 异常编码枚举值
 */
public enum ExceptionCode {


    SERVICE_EXCEPTION("SERVICE_EXCEPTION", "服务异常"),
    DEPENDENCY_EXCEPTION("DEPENDENCY_EXCEPTION", "依赖服务异常");

    private String code;
    private String message;

    ExceptionCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String getCode() {
        return code;
    }

}

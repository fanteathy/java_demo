package me.ele.pts.sample.api;

import me.ele.contract.exception.ServiceException;
import me.ele.pts.sample.api.dto.SampleDto;
import me.ele.pts.sample.api.form.SampleFrom;

/**
 * 服务接口定义
 */
public interface SampleApi {

    /**
     * hello world 接口样例
     *
     * @param form 传入参数表单
     * @return {@link SampleDto} 对象
     * @throws ServiceException 业务异常
     */
    SampleDto helloWorld(SampleFrom form) throws ServiceException;
}

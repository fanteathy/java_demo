package me.ele.pts.sample.api.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * 用于分页返回数据结构
 */
public class PaginationData<E> {

    /**
     * 数据总量
     */
    private int total;

    /**
     * 当前页数据列表
     */
    private List<E> list;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<E> getList() {
        return list;
    }

    public void setList(List<E> list) {
        this.list = list;
    }

    public PaginationData() {
        super();
        this.list = new ArrayList<E>();
    }

    public PaginationData(int total, List<E> list) {
        super();
        this.total = total;
        this.list = list;
    }

    @Override
    public String toString() {
        return "PaginationData [total=" + total + ", list=" + list + "]";
    }

}

package me.ele.pts.sample.api.exception;

import me.ele.contract.exception.ServiceException;

/**
 * 搜索业务异常
 */
public class SampleServiceException extends ServiceException {
    private static final long serialVersionUID = 1L;

    public SampleServiceException(String message) {
        super(message);
    }

    public SampleServiceException(String code, String message) {
        super(code, message);
    }

    public SampleServiceException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public SampleServiceException(String code, Throwable cause) {
        super(code, cause);
    }

    public SampleServiceException(ExceptionCode exceptionCode) {
        super(exceptionCode.getCode(), exceptionCode.getMessage());
    }

    public SampleServiceException(ExceptionCode exceptionCode, Throwable cause) {
        super(exceptionCode.getCode(), exceptionCode.getMessage(), cause);
    }

    public SampleServiceException(ExceptionCode exceptionCode, String message) {
        super(exceptionCode.getCode(), message);
    }

    public SampleServiceException(ExceptionCode exceptionCode, String message, Throwable cause) {
        super(exceptionCode.getCode(), message, cause);
    }

    @Override
    public void setCode(String code) {
        super.setCode(code);
    }

    @Override
    public String getCode() {
        return super.getCode();
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    @Override
    public String getLocalizedMessage() {
        return super.getLocalizedMessage();
    }

    @Override
    public synchronized Throwable getCause() {
        return super.getCause();
    }
}

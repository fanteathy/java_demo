package me.ele.pts.sample.impl.service;

import me.ele.contract.exception.ServiceException;
import me.ele.metrics.statsd.MetricClient;
import me.ele.pts.sample.api.SampleApi;
import me.ele.pts.sample.api.dto.SampleDto;
import me.ele.pts.sample.api.form.SampleFrom;
import me.ele.pts.sample.impl.common.ApplicationContextUtil;
import me.ele.pts.sample.impl.common.HuskarUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

/**
 * 服务样例实现
 */
@Service
public class SampleService implements SampleApi {

    /**
     * 业务打点句柄
     */
    @Autowired
    private  MetricClient metricClient;

    @Override
    public SampleDto helloWorld(SampleFrom form) throws ServiceException {
        SampleDto response = new SampleDto();

        /**
         * huskar 和 metric 使用*/
        if (HuskarUtil.needMetricTest()) {
            // 业务打点: 在指定路径进行计数打点
            metricClient.name("sample", "helloWorld").recordCount(form.getName().length());
        }

        response.setMessage("hello world " + form.getName());
        return response;
    }
}

package me.ele.pts.sample.impl.soa;

import me.ele.contract.iface.IServiceDumper;

/**
 * 服务基本信息查询接口
 */
public class ServiceDump implements IServiceDumper {

    private static final String appid = "pts.sample_service";

    public Object dumpInfo() {
        return new ServiceInfo();
    }

    private static class ServiceInfo {
        private String serviceName = appid;
        private boolean isWorking = true;

        public String getServiceName() {
            return serviceName;
        }

        public boolean isWorking() {
            return isWorking;
        }

        public void setServiceName(String serviceName) {
            this.serviceName = serviceName;
        }

        public void setWorking(boolean working) {
            isWorking = working;
        }
    }
}

package me.ele.pts.sample.impl.common;

import me.ele.config.HuskarHandle;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;

/**
 * huskar 统一读取管理
 * 方便统一查看和配置
 */
public class HuskarUtil {

    private static Log log = LogFactory.getLog(HuskarUtil.class);

    public static String NEED_METRIC_TEST = "NEED_METRIC_TEST";       // huskar 测试配置项

    /**
     * huskar 测试配置项读取
     */
    public static Boolean needMetricTest() {
        return HuskarHandle.get().getMyConfig().getBoolean(NEED_METRIC_TEST, false);
    }
}

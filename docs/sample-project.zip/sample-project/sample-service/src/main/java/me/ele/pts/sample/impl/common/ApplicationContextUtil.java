package me.ele.pts.sample.impl.common;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

/**
 * spring application context 操作工具类
 */
@Service
public class ApplicationContextUtil implements ApplicationContextAware {

    public static ApplicationContext context;

    @Override
    public void setApplicationContext(
            ApplicationContext applicationContext) throws BeansException {
        if(applicationContext != null) {
            context = applicationContext;
        }
    }
}

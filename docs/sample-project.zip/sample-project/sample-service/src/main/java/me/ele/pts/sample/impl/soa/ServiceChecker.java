package me.ele.pts.sample.impl.soa;

import me.ele.contract.iface.IServiceChecker;

/**
 * soa 服务可用性检测接口
 */
public class ServiceChecker implements IServiceChecker {

    public boolean isAvailable() {
        return true;
    }

}

package me.ele.pts.sample.impl;

import me.ele.core.CoreBootstrap;
import me.ele.elog.Log;
import me.ele.elog.LogFactory;
import me.ele.metrics.statsd.MetricClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 注入配置和启动入口
 */
@Configuration
@ComponentScan(basePackages = "me.ele.pts")         // 扫遍路径定义,可为逗号间隔的多个路径
public class MainApplication {


    private static String defaultConfPath = "conf/configure.json";
    private static Log logger = LogFactory.getLog(MainApplication.class);

    @Bean
    public MetricClient metricClient(){
        return new MetricClient();
    }

    public static void main(String... args) {
        try {
            // 启动soa服务
            CoreBootstrap.getInstance().include((args != null && args.length > 0) ?
                    args : new String[]{defaultConfPath}).start();
            // 设置App 为注入配置类
        } catch (Throwable t) {
            logger.error("Throwable Occurs in Container!", t);
            CoreBootstrap.getInstance().stop(-1);
        }

    }
}
package me.ele.pts.sample.impl.soa;

import me.ele.contract.iface.IServiceChecker;
import me.ele.contract.iface.IServiceDumper;
import me.ele.contract.iface.IServiceInitializer;
import me.ele.pts.sample.impl.MainApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 服务初始化接口
 */
public class ServiceInitializer implements IServiceInitializer {

    private ApplicationContext appContext;
    private ServiceChecker serviceChecker;
    private IServiceDumper serviceDumper;

    public void init() {
        appContext = new AnnotationConfigApplicationContext(MainApplication.class);                             // 资源初始化
        serviceChecker = new ServiceChecker();                                          // 初始化服务检测对象
        serviceDumper = new ServiceDump();                                              // 初始化服务状态对象
    }

    public Object getImpl(Class<?> iface) {
        return appContext.getBean(iface);
    }

    public IServiceChecker getChecker() {
        return serviceChecker;
    }

    public IServiceDumper getDumper() {
        return serviceDumper;
    }
}

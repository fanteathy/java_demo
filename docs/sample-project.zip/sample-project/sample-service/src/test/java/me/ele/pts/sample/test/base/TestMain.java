package me.ele.pts.sample.test.base;

import me.ele.pts.sample.impl.MainApplication;

/**
 * 服务启动测试
 */
public class TestMain {

    public void main(String... args) {
        MainApplication.main("deploy/conf/configure.json");
    }
}

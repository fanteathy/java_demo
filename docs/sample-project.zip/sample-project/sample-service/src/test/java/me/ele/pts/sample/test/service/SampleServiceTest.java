package me.ele.pts.sample.test.service;

import me.ele.contract.client.ClientUtil;
import me.ele.contract.exception.ServiceException;
import me.ele.pts.sample.api.SampleApi;
import me.ele.pts.sample.api.dto.SampleDto;
import me.ele.pts.sample.api.form.SampleFrom;
import me.ele.pts.sample.impl.common.ApplicationContextUtil;
import me.ele.pts.sample.test.base.TestBase;
import me.ele.pts.timeline.api.TimeLineNode;
import me.ele.pts.timeline.api.TimeLineSearchService;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


public class SampleServiceTest extends TestBase {

    /**
     * 测试本地服务
     */
    @Test
    public void testServiceFromLocalContext() {
        SampleApi sampleService = ApplicationContextUtil.context.getBean(SampleApi.class);        // 获得服务对象
        SampleFrom form = new SampleFrom();
        form.setName("Test");
        try {
            SampleDto response = sampleService.helloWorld(form);
            assert response != null;
        } catch (ServiceException ex) {
            assertTrue(false);
        }
    }


    /**
     * 依赖服务测试
     * <p>
     * 该测试仅供服务调用方式展示
     * 业务测试无需单独测试依赖服务
     * </p>
     */
    @Test
    public void testTimelineService() {
        TimeLineSearchService timeLineSearchService =
                (TimeLineSearchService) ClientUtil.getContext().getClients(TimeLineSearchService.class);
        List<TimeLineNode> timeLineNodeList = timeLineSearchService.getTimeLine(100011765094425721l);
        assertNotNull(timeLineNodeList);
    }
}

package me.ele.pts.sample.test.base;

import me.ele.contract.client.ClientUtil;
import me.ele.pts.sample.impl.MainApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * 测试基类
 * 当需要初始化soa客户端时可继承该类
 * 该类封装了soa配置初始化步骤
 */
public class TestBase {

    public TestBase() {
        ClientUtil.getContext().initClients("deploy/conf/configure.json");      // 依赖调用初始化
        new AnnotationConfigApplicationContext(MainApplication.class);          // 资源注入
    }

}

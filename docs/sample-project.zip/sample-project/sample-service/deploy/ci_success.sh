#!/usr/bin/env bash
SERVICE_PATH="sample-service"
TARGET_ZIP="sample-service.zip"
unzip -d ${SERVICE_PATH}/deploy/ ${SERVICE_PATH}/target/${TARGET_ZIP}
